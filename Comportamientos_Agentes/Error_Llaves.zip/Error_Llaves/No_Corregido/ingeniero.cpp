#include "ingeniero.hpp"
#include "motorlib/util.h"
#include <iostream>
#include <queue>
#include <set>
#include <cmath>

using namespace std;

// =========================================================================
// ÁREA DE IMPLEMENTACIÓN DEL ESTUDIANTE
// =========================================================================

Action ComportamientoIngeniero::think(Sensores sensores)
{
  Action accion = IDLE;

  // Decisión del agente según el nivel
  switch (sensores.nivel)
  {
  case 0:
    accion = ComportamientoIngenieroNivel_0(sensores);
    break;
  case 1:
    accion = ComportamientoIngenieroNivel_1(sensores);
    break;
  case 2:
    accion = ComportamientoIngenieroNivel_2(sensores);
    break;
  case 3:
    accion = ComportamientoIngenieroNivel_3(sensores);
    break;
  case 4:
    accion = ComportamientoIngenieroNivel_4(sensores);
    break;
  case 5:
    accion = ComportamientoIngenieroNivel_5(sensores);
    break;
  case 6:
    accion = ComportamientoIngenieroNivel_6(sensores);
    break;
  }

  return accion;
}

static void Coordenadas(Sensores sensores, int &fI, int &cI, int &fC, int &cC, int &fD, int &cD){
   switch (sensores.rumbo) {
      case norte:
         fI = sensores.posF - 1; cI = sensores.posC - 1;
         fC = sensores.posF - 1; cC = sensores.posC;
         fD = sensores.posF - 1; cD = sensores.posC + 1;
         break;
      case noreste:
         fI = sensores.posF - 1; cI = sensores.posC;
         fC = sensores.posF - 1; cC = sensores.posC + 1;
         fD = sensores.posF;     cD = sensores.posC + 1;
         break;
      case este:
         fI = sensores.posF - 1; cI = sensores.posC + 1;
         fC = sensores.posF;     cC = sensores.posC + 1;
         fD = sensores.posF + 1; cD = sensores.posC + 1;
         break;
      case sureste:
         fI = sensores.posF;     cI = sensores.posC + 1;
         fC = sensores.posF + 1; cC = sensores.posC + 1;
         fD = sensores.posF + 1; cD = sensores.posC;
         break;
      case sur:
         fI = sensores.posF + 1; cI = sensores.posC + 1;
         fC = sensores.posF + 1; cC = sensores.posC;
         fD = sensores.posF + 1; cD = sensores.posC - 1;
         break;
      case suroeste:
         fI = sensores.posF + 1; cI = sensores.posC;
         fC = sensores.posF + 1; cC = sensores.posC - 1;
         fD = sensores.posF;     cD = sensores.posC - 1;
         break;
      case oeste:
         fI = sensores.posF + 1; cI = sensores.posC - 1;
         fC = sensores.posF;     cC = sensores.posC - 1;
         fD = sensores.posF - 1; cD = sensores.posC - 1;
         break;
      case noroeste:
         fI = sensores.posF;     cI = sensores.posC - 1;
         fC = sensores.posF - 1; cC = sensores.posC - 1;
         fD = sensores.posF - 1; cD = sensores.posC;
         break;
   }
}

/**
 * @brief Determina la mejor opcion entre las 3 casillas que tiene delante
 * 
 * @param i terreno que hay en la posicion 1 de la superficie
 * @param c terreno que hay en la posicion 2 de la superficie
 * @param d terreno que hay en la posicion 3 de la superficie
 * @return 2 si es mejor WALK, 1 para TURN_SL y 3 para TURN_SR, 0 si no hay nada interesante
 */
int VeoCasillaInteresanteI0(char i, char c, char d, bool zapatillas, int calorI, int calorC, int calorD){
   if(c == 'U') return 2;
   else if(i == 'U') return 1;
   else if(d == 'U') return 3;

   if(!zapatillas){
      if(c == 'D') return 2;
      else if(i == 'D') return 1;
      else if(d == 'D') return 3;
   }

   bool viableI = (i == 'C' || i == 'D');
   bool viableC = (c == 'C' || c == 'D');
   bool viableD = (d == 'C' || d == 'D');

   if (!viableI && !viableC && !viableD) return 0;

   int mejorOpcion = 0;
   int menorCalor = 9999;

   if (viableC && calorC <= menorCalor) { 
      menorCalor = calorC; 
      mejorOpcion = 2; 
   }
   
   if (viableI && calorI < menorCalor) { 
      menorCalor = calorI; 
      mejorOpcion = 1; 
   }
   
   if (viableD && calorD < menorCalor) { 
      menorCalor = calorD; 
      mejorOpcion = 3; 
   }

   return mejorOpcion;
}

/**
 * @brief Determina si la casilla es viable por altura.
 * @param casilla tipo de terreno
 * @param dif diferencia de altura entre casillas
 * @param zapatillas indica si tengo las zapatillas
 * @return 'P' si no es accesible por altura y casilla en otro caso
 */
char ViablePorAlturaI0(char casilla, int dif, bool zapatillas){
   if(abs(dif) <= 1 || (zapatillas && abs(dif) <= 2))
      return casilla;
   else
      return 'P';
}

// Niveles iniciales (Comportamientos reactivos simples)
Action ComportamientoIngeniero::ComportamientoIngenieroNivel_0(Sensores sensores)
{
   Action accion = IDLE;
   ActualizarMapa(sensores);

   if(sensores.superficie[0] == 'U') return IDLE;

   if(sensores.superficie[0] == 'D' && !zapatillas) zapatillas = true;

   if(accion_anterior == WALK) mapaCalor[{sensores.posF, sensores.posC}]++;


   char i = ViablePorAlturaI0(sensores.superficie[1], sensores.cota[1] - sensores.cota[0], zapatillas);
   char c = ViablePorAlturaI0(sensores.superficie[2], sensores.cota[2] - sensores.cota[0], zapatillas);
   char d = ViablePorAlturaI0(sensores.superficie[3], sensores.cota[3] - sensores.cota[0], zapatillas);

   if (sensores.agentes[1] != '_') i = 'P';
   if (sensores.agentes[2] != '_') c = 'P';
   if (sensores.agentes[3] != '_') d = 'P';

   int fI, cI, fC, cC, fD, cD;

   Coordenadas(sensores, fI, cI, fC, cC, fD, cD);

   int calorI = mapaCalor[{fI, cI}];
   int calorC = mapaCalor[{fC, cC}];
   int calorD = mapaCalor[{fD, cD}];

   int pos = VeoCasillaInteresanteI0(i, c, d, zapatillas, calorI, calorC, calorD);

   switch (pos)
   {
   case 2:
      accion = WALK;
      break;
   case 1:
      accion = TURN_SL;
      break;
   case 3:
      accion = TURN_SR;
      break;
   default:
      accion = TURN_SL;
      break;
   }

   accion_anterior = accion;
   return accion;
}

/**
 * @brief Comprueba si una celda es de tipo camino transitable.
 * @param c Carácter que representa el tipo de superficie.
 * @return true si es camino ('C'), zapatillas ('D') o meta ('U').
 */
bool ComportamientoIngeniero::es_camino(unsigned char c) const
{
  return (c == 'C' || c == 'D' || c == 'U');
}

/**
 * @brief Función auxiliar para darle un valor de "esfuerzo" a cada terreno.
 * @return Devuelve el "coste" de pisar ese terreno
 */
int ObtenerCosteTerrenoI1(unsigned char c, bool zapatillas) {
   if (c == 'U') return 0;
   if (c == 'C' || c == 'D') return 1;
   if (c == 'S') return 2;
   if (c == 'H') return 3;
    
   return 9999;
}

/**
 * @brief Determina la mejor opcion entre las 3 casillas que tiene delante
 * 
 * @param i terreno que hay en la posicion 1 de la superficie
 * @param c terreno que hay en la posicion 2 de la superficie
 * @param d terreno que hay en la posicion 3 de la superficie
 * @param calorI Veces que se ha pisado la casilla izquierda
 * @param calorC Veces que se ha pisado la casilla delantera
 * @param calorD Veces que se ha pisado la casilla derecha
 * @return 2 si es mejor WALK, 1 para TURN_SL y 3 para TURN_SR, 0 si no hay nada interesante
 */
int VeoCasillaInteresanteI1(char i, char c, char d, bool zapatillas, int calorI, int calorC, int calorD){
   if (!zapatillas) {
      if (c == 'D') return 2;
      else if (i == 'D') return 1;
      else if (d == 'D') return 3;
   }

   int costeI = ObtenerCosteTerrenoI1(i, zapatillas);
   int costeC = ObtenerCosteTerrenoI1(c, zapatillas);
   int costeD = ObtenerCosteTerrenoI1(d, zapatillas);

   if (costeI == 9999 && costeC == 9999 && costeD == 9999) return 0;

   costeI += (calorI * 10);
   costeC += (calorC * 10);
   costeD += (calorD * 10);
   
   int mejorOpcion = 0;
   int mejorCoste = 99999;

   if (costeI < mejorCoste) { 
      mejorCoste = costeI; 
      mejorOpcion = 1;
   }

   if (costeC <= mejorCoste) { 
      mejorCoste = costeC; 
      mejorOpcion = 2;
   }
   
   if (costeD < mejorCoste) { 
      mejorCoste = costeD; 
      mejorOpcion = 3;
   }

   return mejorOpcion;
}

/**
 * @brief Determina si la casilla es viable por altura.
 * @param casilla tipo de terreno
 * @param dif diferencia de altura entre casillas
 * @param zapatillas indica si tengo las zapatillas
 * @return 'P' si no es accesible por altura y casilla en otro caso
 */
char ViablePorAlturaI1(char casilla, int dif, bool zapatillas){
   if(abs(dif) <= 1 || (zapatillas && abs(dif) <= 2))
      return casilla;
   else
      return 'P';
}

/**
 * @brief Comportamiento reactivo del ingeniero para el Nivel 1.
 * @param sensores Datos actuales de los sensores.
 * @return Acción a realizar.
 */
Action ComportamientoIngeniero::ComportamientoIngenieroNivel_1(Sensores sensores)
{
   Action accion = IDLE;
   ActualizarMapa(sensores);

   if (sensores.superficie[0] == 'D' && !zapatillas) zapatillas = true;

   if(accion_anterior == WALK) mapaCalor[{sensores.posF, sensores.posC}]++;

   char i = ViablePorAlturaI1(sensores.superficie[1], sensores.cota[1] - sensores.cota[0], zapatillas);
   char c = ViablePorAlturaI1(sensores.superficie[2], sensores.cota[2] - sensores.cota[0], zapatillas);
   char d = ViablePorAlturaI1(sensores.superficie[3], sensores.cota[3] - sensores.cota[0], zapatillas);

   if (sensores.agentes[1] != '_') i = 'P';
   if (sensores.agentes[2] != '_') c = 'P';
   if (sensores.agentes[3] != '_') d = 'P';

   int fI, cI, fC, cC, fD, cD;

   Coordenadas(sensores, fI, cI, fC, cC, fD, cD);

   int calorI = mapaCalor[{fI, cI}];
   int calorC = mapaCalor[{fC, cC}];
   int calorD = mapaCalor[{fD, cD}];

   int pos = VeoCasillaInteresanteI1(i, c, d, zapatillas, calorI, calorC, calorD);

   switch (pos)
   {
   case 2:
      accion = WALK;
      break;
   case 1:
      accion = TURN_SL;
      break;
   case 3:
      accion = TURN_SR;
      break;
   default:
      accion = TURN_SL;
      break;
   }

   accion_anterior = accion;
   return accion;
}

// Niveles avanzados (Uso de búsqueda)

ubicacion SiguienteCasillaI(const ubicacion &origen, int pasos = 1) {
   ubicacion sig = origen;
   switch (origen.brujula) {
      case norte:    sig.f -= pasos; break;
      case noreste:  sig.f -= pasos; sig.c += pasos; break;
      case este:     sig.c += pasos; break;
      case sureste:  sig.f += pasos; sig.c += pasos; break;
      case sur:      sig.f += pasos; break;
      case suroeste: sig.f += pasos; sig.c -= pasos; break;
      case oeste:    sig.c -= pasos; break;
      case noroeste: sig.f -= pasos; sig.c -= pasos; break;
   }
   return sig;
}

bool EsMovimientoLegalI(Action accion, const EstadoI &st, const vector<vector<unsigned char>> &terreno, const vector<vector<unsigned char>> &altura, const vector<vector<unsigned char>> &agentes) {
   if (accion == TURN_SL || accion == TURN_SR) return true;
 
   ubicacion origen = st.site;
   ubicacion destino;
   
   if (accion == WALK) {
      destino = SiguienteCasillaI(origen, 1);
      if (destino.f < 0 || destino.f >= terreno.size() || destino.c < 0 || destino.c >= terreno[0].size()) return false;
      if (agentes[destino.f][destino.c] != '_') return false; 
   }
   else if (accion == JUMP) {
      destino = SiguienteCasillaI(origen, 2);
      ubicacion intermedia = SiguienteCasillaI(origen, 1);
 
      if (intermedia.f < 0 || intermedia.f >= (int)terreno.size() || intermedia.c < 0 || intermedia.c >= (int)terreno[0].size()) return false;
      
      unsigned char terr_int = terreno[intermedia.f][intermedia.c];

      if (terr_int == 'M' || terr_int == 'P' || terr_int == 'B' || terr_int == '?') return false;
      if (agentes[intermedia.f][intermedia.c] != '_') return false; 
   } else
      return false;
 
   if (destino.f < 0 || destino.f >= terreno.size() || destino.c < 0 || destino.c >= terreno[0].size()) return false;
 
   unsigned char terr_dest = terreno[destino.f][destino.c];

   if (terr_dest == 'M' || terr_dest == 'P' || terr_dest == 'B' || terr_dest == '?') return false;
 
   int alt_origen = altura[origen.f][origen.c];
   int alt_dest = altura[destino.f][destino.c];
   int dif_altura = abs(alt_dest - alt_origen);
   
   int dif_maxima = st.zapatillas ? 2 : 1;
   
   if (dif_altura > dif_maxima) return false;
 
   return true;
}

EstadoI AplicarAccionI(Action accion, const EstadoI &st, const vector<vector<unsigned char>> &terreno) {
   EstadoI next_st = st;
 
   switch (accion) {
      case WALK:
         next_st.site = SiguienteCasillaI(st.site, 1);
         break;
      case JUMP:
         next_st.site = SiguienteCasillaI(st.site, 2);
         break;
      case TURN_SL:
         next_st.site.brujula = (Orientacion)(((int)st.site.brujula + 7) % 8);
         break;
      case TURN_SR:
         next_st.site.brujula = (Orientacion)(((int)st.site.brujula + 1) % 8);
         break;
   }
 
   if (next_st.site.f >= 0 && next_st.site.f < (int)terreno.size() && 
       next_st.site.c >= 0 && next_st.site.c < (int)terreno[0].size() && 
       terreno[next_st.site.f][next_st.site.c] == 'D')
      next_st.zapatillas = true;
 
   return next_st;
}

list<Action> B_Anchura_Ingeniero(const EstadoI &inicio, const ubicacion &final, const vector<vector<unsigned char>> &terreno, const vector<vector<unsigned char>> &altura, const vector<vector<unsigned char>> &agentes) {
   queue<NodoI> frontier;
   set<EstadoI> explored;

   NodoI nodo_inicial;
   nodo_inicial.estado = inicio;
   
   frontier.push(nodo_inicial);
   explored.insert(inicio);

   vector<Action> acciones_posibles = {WALK, JUMP, TURN_SL, TURN_SR};

   while (!frontier.empty()) {
      NodoI current_node = frontier.front();
      frontier.pop();

      if (current_node.estado.site.f == final.f && current_node.estado.site.c == final.c)
         return current_node.secuencia;

      for (Action accion : acciones_posibles) {
         if (EsMovimientoLegalI(accion, current_node.estado, terreno, altura, agentes)) {
            NodoI child;
            child.estado = AplicarAccionI(accion, current_node.estado, terreno);
            
            if (explored.find(child.estado) == explored.end()) {
               child.secuencia = current_node.secuencia;
               child.secuencia.push_back(accion);
               
               frontier.push(child);
               explored.insert(child.estado);
            }
         }
      }
   }

   return {};
}

/**
 * @brief Comportamiento del ingeniero para el Nivel 2 (búsqueda).
 * @param sensores Datos actuales de los sensores.
 * @return Acción a realizar.
 */
Action ComportamientoIngeniero::ComportamientoIngenieroNivel_2(Sensores sensores)
{
   Action accion = IDLE;

   if (sensores.superficie[0] == 'D') zapatillas = true;

   if (matrizAgentes.empty() && mapaResultado.size() > 0)
      matrizAgentes.assign(mapaResultado.size(), vector<unsigned char>(mapaResultado[0].size(), '_'));

   if (!hayPlan) {
      EstadoI inicio;
      inicio.site.f = sensores.posF;
      inicio.site.c = sensores.posC;
      inicio.site.brujula = sensores.rumbo;
      inicio.zapatillas = this->zapatillas; 
      
      ubicacion objetivo;
      objetivo.f = sensores.BelPosF;
      objetivo.c = sensores.BelPosC;

      plan = B_Anchura_Ingeniero(inicio, objetivo, mapaResultado, mapaCotas, matrizAgentes);
      
      if (plan.size() > 0) {
         VisualizaPlan(inicio.site, plan);
         hayPlan = true;
      }
   }

   if (hayPlan && !plan.empty()) {
      Action a = plan.front();
      bool choque = false;

      if (a == WALK && sensores.agentes[2] != '_')
         choque = true;

      else if (a == JUMP) {
         if (sensores.agentes[2] != '_') choque = true;
         if (sensores.agentes[6] != '_') choque = true;
      }

      if (choque)
         accion = IDLE;
      else {
         accion = plan.front();
         plan.pop_front();
      }
   }

   if (plan.size() == 0)
      hayPlan = false;

   return accion;
}

/**
 * @brief Comportamiento del ingeniero para el Nivel 3.
 * @param sensores Datos actuales de los sensores.
 * @return Acción a realizar.
 */
Action ComportamientoIngeniero::ComportamientoIngenieroNivel_3(Sensores sensores)
{
   Action accion = TURN_SL;

   if (sensores.superficie[0] == 'D') zapatillas = true;

   bool tecnicoCerca = false;
   for (int i = 1; i <= 8; i++) {
      if (sensores.agentes[i] == 't') {
         tecnicoCerca = true;
         break;
      }
   }

   if (tecnicoCerca) {
      int dif_altura = abs(sensores.cota[2] - sensores.cota[0]);
      int dif_maxima = zapatillas ? 2 : 1;
      
      if (sensores.superficie[2] != 'M' && sensores.superficie[2] != 'P' && 
          sensores.superficie[2] != 'B' && sensores.agentes[2] == '_' && 
          dif_altura <= dif_maxima) {
         accion = WALK;
      } else
         accion = TURN_SL;
   }

   return accion;
}

int CalcularEnergiaTuberiaI(unsigned char terreno, int op) {
   int energia = 0;
   
   if (terreno == 'A') energia += 60;
   else if (terreno == 'H') energia += 45;
   else if (terreno == 'S') energia += 25;
   else if (terreno == 'C' || terreno == 'U') energia += 15;
   else energia += 30; 

   if (op == 1) {
      if (terreno == 'H') energia += 55;
      else if (terreno == 'S') energia += 30;
      else if (terreno == 'C' || terreno == 'U') energia += 10;
      else energia += 40;
   }
   else if (op == -1) {
      if (terreno == 'H') energia += 65;
      else if (terreno == 'S') energia += 40;
      else if (terreno == 'C' || terreno == 'U') energia += 25;
      else energia += 50;
   }
   return energia;
}

int CalcularEcoTuberiaI(unsigned char terreno, int op) {
   int eco = 0;
    
   if (terreno == 'A') eco += 50;
   else if (terreno == 'H') eco += 45;
   else if (terreno == 'S') eco += 25;
   else if (terreno == 'C' || terreno == 'U') eco += 15;
   else eco += 30;

   if (op == 1) {
      if (terreno == 'H') eco += 55;
      else if (terreno == 'S') eco += 30;
      else if (terreno == 'C' || terreno == 'U') eco += 10;
      else eco += 40;
   }
   else if (op == -1) {
      if (terreno == 'H') eco += 65;
      else if (terreno == 'S') eco += 40;
      else if (terreno == 'C' || terreno == 'U') eco += 25;
      else eco += 50;
   }
   return eco;
}

list<Paso> Algoritmo_Tuberias_Ingeniero(int inicio_f, int inicio_c, const vector<vector<unsigned char>> &terreno, const vector<vector<unsigned char>> &altura, int max_energia, int max_eco) {
   priority_queue<NodoTuberiaI, vector<NodoTuberiaI>, greater<NodoTuberiaI>> frontier;
   int filas = terreno.size(), cols = terreno[0].size();
   map<Padre, int> min_eco_visto; 

   for (int i = -1; i <= 1; i++) {
      unsigned char t_ini = terreno[inicio_f][inicio_c];
      if ((i == 0 || t_ini != 'A') && (i != 1 || altura[inicio_f][inicio_c] < 9) && (i != -1 || altura[inicio_f][inicio_c] > 1)) {
         NodoTuberiaI inicial;
         inicial.f = inicio_f; inicial.c = inicio_c; inicial.op = i;
         inicial.altura_mod = altura[inicio_f][inicio_c] + i;
         inicial.dist = 1;
         
         int coste_base_ene = CalcularEnergiaTuberiaI(t_ini, 0);
         int coste_base_eco = CalcularEcoTuberiaI(t_ini, 0);
         inicial.energia = CalcularEnergiaTuberiaI(t_ini, i) - coste_base_ene;
         inicial.eco = CalcularEcoTuberiaI(t_ini, i) - coste_base_eco;

         if (inicial.energia <= max_energia && inicial.eco <= max_eco) {
            inicial.camino.push_back({inicio_f, inicio_c, i});
            frontier.push(inicial);
            min_eco_visto[{inicio_f, inicio_c, i}] = inicial.eco;
         }
      }
   }

   int df[] = {-1, 1, 0, 0}, dc[] = {0, 0, 1, -1};

   while (!frontier.empty()) {
      NodoTuberiaI actual = frontier.top();
      frontier.pop();

      if (terreno[actual.f][actual.c] == 'U') return actual.camino;

      for (int i = 0; i < 4; i++) {
         int nf = actual.f + df[i], nc = actual.c + dc[i];
         if (nf >= 0 && nf < filas && nc >= 0 && nc < cols) {
            unsigned char t = terreno[nf][nc];

            if (t != 'M' && t != 'P' && t != 'B' && t != '?') {
               for (int nop = -1; nop <= 1; nop++) {
                  if (!(nop != 0 && t == 'A') && !(nop == 1 && altura[nf][nc] >= 9) && !(nop == -1 && altura[nf][nc] <= 1)) {
                     int nalt = altura[nf][nc] + nop;
                     int dif_alt = actual.altura_mod - nalt;
                     
                     if (dif_alt == 0 || dif_alt == 1) {
                        int n_energia = actual.energia + CalcularEnergiaTuberiaI(t, nop);
                        int eco_inst_actual = CalcularEcoTuberiaI(terreno[actual.f][actual.c], 0);
                        int n_eco = actual.eco + eco_inst_actual + CalcularEcoTuberiaI(t, nop);
                        
                        if (n_energia <= max_energia && n_eco <= max_eco) {
                           Padre estado_hijo = {nf, nc, nop};
                           if (min_eco_visto.find(estado_hijo) == min_eco_visto.end() || n_eco < min_eco_visto[estado_hijo]) {
                              min_eco_visto[estado_hijo] = n_eco;
                              
                              NodoTuberiaI hijo;
                              hijo.f = nf; hijo.c = nc; hijo.op = nop;
                              hijo.altura_mod = nalt;
                              hijo.energia = n_energia; hijo.eco = n_eco; 
                              hijo.dist = actual.dist + 1;
                              hijo.camino = actual.camino; 
                              hijo.camino.push_back({nf, nc, nop}); 
                              frontier.push(hijo);
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   return {}; 
}

/**
 * @brief Comportamiento del ingeniero para el Nivel 4.
 * @param sensores Datos actuales de los sensores.
 * @return Acción a realizar.
 */
Action ComportamientoIngeniero::ComportamientoIngenieroNivel_4(Sensores sensores)
{
   if (hayPlan) return IDLE;

   int eco_disponible = sensores.max_ecologico - sensores.ecologico;

   list<Paso> plan_tuberias = Algoritmo_Tuberias_Ingeniero(
      sensores.BelPosF, 
      sensores.BelPosC, 
      mapaResultado, 
      mapaCotas,
      sensores.energia,
      eco_disponible
   );

   if (!plan_tuberias.empty()) {
      VisualizaRedTuberias(plan_tuberias);
      hayPlan = true;
   }

   return IDLE;
}

Orientacion CalcularOrientacionHaciaObjetivoI(int fila_origen, int col_origen, int fila_destino, int col_destino) {
   if (fila_destino < fila_origen && col_destino == col_origen) return norte;
   if (fila_destino > fila_origen && col_destino == col_origen) return sur;
   if (fila_destino == fila_origen && col_destino < col_origen) return oeste;
   if (fila_destino == fila_origen && col_destino > col_origen) return este;
   return norte; 
}

Action NavegarHaciaDestinoI(Sensores &sensores, ubicacion objetivo, bool tiene_zapatillas, const vector<vector<unsigned char>> &mapaResultado, const vector<vector<unsigned char>> &mapaCotas, const vector<Paso> &plan, int idx_tecnico, list<Action> &ruta_nav, int &intentos_bloqueo) {
   if (ruta_nav.empty()) {
      EstadoI inicio;
      inicio.site.f = sensores.posF; inicio.site.c = sensores.posC; inicio.site.brujula = sensores.rumbo; inicio.zapatillas = tiene_zapatillas;
      vector<vector<unsigned char>> mapa_agentes(mapaResultado.size(), vector<unsigned char>(mapaResultado[0].size(), '_'));
      if (idx_tecnico >= 0 && idx_tecnico < plan.size())
         mapa_agentes[plan[idx_tecnico].fil][plan[idx_tecnico].col] = 't';
   
      ruta_nav = B_Anchura_Ingeniero(inicio, objetivo, mapaResultado, mapaCotas, mapa_agentes);
   }
   
   if (!ruta_nav.empty()) {
      Action a = ruta_nav.front();
      bool colision = false;
      int max_dif = tiene_zapatillas ? 2 : 1;

      if (a == WALK) {
         if (sensores.agentes[2] != '_') colision = true;
         if (abs(sensores.cota[2] - sensores.cota[0]) > max_dif)
            ruta_nav.clear(); return IDLE;
      }
      else if (a == JUMP) {
         if (sensores.agentes[2] != '_' || sensores.agentes[6] != '_') colision = true;
         if (abs(sensores.cota[6] - sensores.cota[0]) > max_dif)
            ruta_nav.clear(); return IDLE;
      }

      if (colision) {
         intentos_bloqueo++;
         if (intentos_bloqueo > 3)
            ruta_nav.clear(); intentos_bloqueo = 0;

         return IDLE;
      }
      
      intentos_bloqueo = 0;
      ruta_nav.pop_front();
      return a;
   }

   ruta_nav.clear();
   intentos_bloqueo++;
   return TURN_SR;
}

/**
 * @brief Comportamiento del ingeniero para el Nivel 5.
 * @param sensores Datos actuales de los sensores.
 * @return Acción a realizar.
 */
Action ComportamientoIngeniero::ComportamientoIngenieroNivel_5(Sensores sensores)
{
   ActualizarMapa(sensores);
   if (sensores.superficie[0] == 'D') zapatillas = true;

   if (fase_actual == 0) {
      int eco_disponible = sensores.max_ecologico - sensores.ecologico;

      list<Paso> ruta_tuberias = Algoritmo_Tuberias_Ingeniero(sensores.BelPosF, sensores.BelPosC, mapaResultado, mapaCotas, sensores.energia, eco_disponible);
      
      if (ruta_tuberias.size() < 2) return IDLE;
      
      for (auto tramo : ruta_tuberias) 
         plan_construccion.push_back(tramo);

      fase_actual = 1;
      indice_tramo = 0;
   }

   if (fase_actual == 1) {
      while (indice_tramo < plan_construccion.size() && plan_construccion[indice_tramo].op == 0) {
         indice_tramo++;
      }
      
      if (indice_tramo >= plan_construccion.size()) {
         fase_actual = 2; 
         indice_tramo = 0;
         ruta_nav.clear();
         return IDLE;
      }
      
      Paso tramo_objetivo = plan_construccion[indice_tramo];
      if (sensores.posF == tramo_objetivo.fil && sensores.posC == tramo_objetivo.col) {
         Action accion_terreno = (tramo_objetivo.op == 1) ? RAISE : DIG;
         plan_construccion[indice_tramo].op = 0; 
         ruta_nav.clear();
         return accion_terreno;
      } else {
         ubicacion posicion_destino; 
         posicion_destino.f = tramo_objetivo.fil; 
         posicion_destino.c = tramo_objetivo.col;
         return NavegarHaciaDestinoI(sensores, posicion_destino, zapatillas, mapaResultado, mapaCotas, plan_construccion, -1, ruta_nav, intentos_bloqueo);
      }
   }

   if (fase_actual == 2) {
      if (plan_construccion.size() < 2) return IDLE; 
      
      Paso casilla_tecnico = plan_construccion[0];
      Paso casilla_ingeniero = plan_construccion[1];
      
      if (sensores.posF == casilla_ingeniero.fil && sensores.posC == casilla_ingeniero.col) {
         Orientacion orientacion_necesaria = CalcularOrientacionHaciaObjetivoI(casilla_ingeniero.fil, casilla_ingeniero.col, casilla_tecnico.fil, casilla_tecnico.col);
         
         if (sensores.rumbo == orientacion_necesaria) {
            fase_actual = 3;
            indice_tramo = 0;
            ruta_nav.clear();
            return COME;
         } else
            return TURN_SL;
      } else {
         ubicacion posicion_destino; 
         posicion_destino.f = casilla_ingeniero.fil; 
         posicion_destino.c = casilla_ingeniero.col;
         return NavegarHaciaDestinoI(sensores, posicion_destino, zapatillas, mapaResultado, mapaCotas, plan_construccion, 0, ruta_nav, intentos_bloqueo);
      }
   }

   if (fase_actual == 3) {
      if (indice_tramo >= plan_construccion.size() - 1) return IDLE; 

      Paso casilla_tecnico = plan_construccion[indice_tramo];
      Paso casilla_ingeniero = plan_construccion[indice_tramo + 1];

      if (sensores.posF == casilla_ingeniero.fil && sensores.posC == casilla_ingeniero.col) {
         Orientacion orientacion_necesaria = CalcularOrientacionHaciaObjetivoI(casilla_ingeniero.fil, casilla_ingeniero.col, casilla_tecnico.fil, casilla_tecnico.col);
         
         if (sensores.rumbo == orientacion_necesaria) {
            if (sensores.enfrente) {
               indice_tramo++; 
               ruta_nav.clear(); 
               return INSTALL;
            } else
               return IDLE; 
         } else
            return TURN_SL;
      } else {
         ubicacion posicion_destino; 
         posicion_destino.f = casilla_ingeniero.fil; 
         posicion_destino.c = casilla_ingeniero.col;
         return NavegarHaciaDestinoI(sensores, posicion_destino, zapatillas, mapaResultado, mapaCotas, plan_construccion, indice_tramo, ruta_nav, intentos_bloqueo);
      }
   }

   return IDLE;
}

/**
 * @brief Comportamiento del ingeniero para el Nivel 6.
 * @param sensores Datos actuales de los sensores.
 * @return Acción a realizar.
 */
Action ComportamientoIngeniero::ComportamientoIngenieroNivel_6(Sensores sensores)
{
   ActualizarMapa(sensores);
   if (sensores.superficie[0] == 'D') zapatillas = true;

   if (fase_actual == 0) {
      bool conozco_U = false;
      
      if(mapaResultado.size() > 0 && mapaResultado[0].size() > 0) {
         bool salida = false;

         for(int i=0; i<mapaResultado.size() && !salida; i++){
            for(int j=0; j<mapaResultado[0].size() && !salida; j++){
               if(mapaResultado[i][j] == 'U') {
                  conozco_U = true; 
                  salida == true;
               }
            }
            if(conozco_U) break;
         }
      }

      bool conozco_Belkanita = (sensores.BelPosF != -1 && sensores.BelPosC != -1);

      int ciclos_exploracion = 0;
      ciclos_exploracion++;

      if (conozco_U && conozco_Belkanita && (ciclos_exploracion % 15 == 0)) { 
         int eco_disponible = sensores.max_ecologico - sensores.ecologico;
         list<Paso> ruta_tuberias = Algoritmo_Tuberias_Ingeniero(sensores.BelPosF, sensores.BelPosC, mapaResultado, mapaCotas, sensores.energia, eco_disponible);
         
         if (ruta_tuberias.size() >= 2) {
            plan_construccion.clear();
            for (auto tramo : ruta_tuberias) plan_construccion.push_back(tramo);
            fase_actual = 1; 
            indice_tramo = 0;
            ruta_nav.clear();
            intentos_bloqueo = 0;
            return IDLE;
         }
      }
      return ComportamientoIngenieroNivel_1(sensores);
   }

   if (fase_actual == 1) {
      while (indice_tramo < (int)plan_construccion.size() && plan_construccion[indice_tramo].op == 0) {
         indice_tramo++;
      }
      
      if (plan_construccion.empty() || indice_tramo >= (int)plan_construccion.size()) {
         fase_actual = 2; 
         indice_tramo = 0;
         ruta_nav.clear();
         return IDLE;
      }
      
      Paso tramo_objetivo = plan_construccion[indice_tramo];
      if (sensores.posF == tramo_objetivo.fil && sensores.posC == tramo_objetivo.col) {
         Action accion_terreno = (tramo_objetivo.op == 1) ? RAISE : DIG;
         plan_construccion[indice_tramo].op = 0; 
         ruta_nav.clear();
         return accion_terreno;
      } else {
         ubicacion posicion_destino; 
         posicion_destino.f = tramo_objetivo.fil; 
         posicion_destino.c = tramo_objetivo.col;
         Action act = NavegarHaciaDestinoI(sensores, posicion_destino, zapatillas, mapaResultado, mapaCotas, plan_construccion, -1, ruta_nav, intentos_bloqueo);
         
         if (intentos_bloqueo > 3 || (act == TURN_SR && ruta_nav.empty() && intentos_bloqueo > 0))
            fase_actual = 0; plan_construccion.clear(); ruta_nav.clear(); intentos_bloqueo = 0;

         return act;
      }
   }

   if (fase_actual == 2) {
      if (plan_construccion.size() < 2) { 
         fase_actual = 0; 
         plan_construccion.clear(); 
         return IDLE; 
      }
      
      Paso casilla_tecnico = plan_construccion[0];
      Paso casilla_ingeniero = plan_construccion[1];
      
      if (sensores.posF == casilla_ingeniero.fil && sensores.posC == casilla_ingeniero.col) {
         Orientacion orientacion_necesaria = CalcularOrientacionHaciaObjetivoI(casilla_ingeniero.fil, casilla_ingeniero.col, casilla_tecnico.fil, casilla_tecnico.col);
         if (sensores.rumbo == orientacion_necesaria) {
            fase_actual = 3;
            indice_tramo = 0;
            ruta_nav.clear();
            return COME;
         } else
            return TURN_SL;
      } else {
         ubicacion posicion_destino; 
         posicion_destino.f = casilla_ingeniero.fil; 
         posicion_destino.c = casilla_ingeniero.col;
         Action act = NavegarHaciaDestinoI(sensores, posicion_destino, zapatillas, mapaResultado, mapaCotas, plan_construccion, 0, ruta_nav, intentos_bloqueo);
         if (intentos_bloqueo > 3) 
            fase_actual = 0; plan_construccion.clear(); ruta_nav.clear(); intentos_bloqueo = 0;

         return act;
      }
   }

   if (fase_actual == 3) {
      if (plan_construccion.empty() || indice_tramo >= (int)plan_construccion.size() - 1)
         fase_actual = 0; plan_construccion.clear(); return IDLE; 

      Paso casilla_tecnico = plan_construccion[indice_tramo];
      Paso casilla_ingeniero = plan_construccion[indice_tramo + 1];

      if (sensores.posF == casilla_ingeniero.fil && sensores.posC == casilla_ingeniero.col) {
         Orientacion orientacion_necesaria = CalcularOrientacionHaciaObjetivoI(casilla_ingeniero.fil, casilla_ingeniero.col, casilla_tecnico.fil, casilla_tecnico.col);
         
         if (sensores.rumbo == orientacion_necesaria) {
            if (sensores.enfrente) {
               indice_tramo++; 
               ruta_nav.clear(); 
               return INSTALL;
            } else
               return COME; 
         } else
            return TURN_SL;
      } else {
         ubicacion posicion_destino; 
         posicion_destino.f = casilla_ingeniero.fil; 
         posicion_destino.c = casilla_ingeniero.col;
         Action act = NavegarHaciaDestinoI(sensores, posicion_destino, zapatillas, mapaResultado, mapaCotas, plan_construccion, indice_tramo, ruta_nav, intentos_bloqueo);
         if (intentos_bloqueo > 3)
            fase_actual = 0; plan_construccion.clear(); ruta_nav.clear(); intentos_bloqueo = 0;
            
         return act;
      }
   }

   return IDLE;
}

// =========================================================================
// FUNCIONES PROPORCIONADAS
// =========================================================================

/**
 * @brief Actualiza el mapaResultado y mapaCotas con la información de los sensores.
 * @param sensores Datos actuales de los sensores.
 */
void ComportamientoIngeniero::ActualizarMapa(Sensores sensores)
{
  mapaResultado[sensores.posF][sensores.posC] = sensores.superficie[0];
  mapaCotas[sensores.posF][sensores.posC] = sensores.cota[0];

  int pos = 1;
  switch (sensores.rumbo)
  {
  case norte:
    for (int j = 1; j < 4; j++)
      for (int i = -j; i <= j; i++)
      {
        mapaResultado[sensores.posF - j][sensores.posC + i] = sensores.superficie[pos];
        mapaCotas[sensores.posF - j][sensores.posC + i] = sensores.cota[pos++];
      }
    break;
  case noreste:
    mapaResultado[sensores.posF - 1][sensores.posC] = sensores.superficie[1];
    mapaCotas[sensores.posF - 1][sensores.posC] = sensores.cota[1];
    mapaResultado[sensores.posF - 1][sensores.posC + 1] = sensores.superficie[2];
    mapaCotas[sensores.posF - 1][sensores.posC + 1] = sensores.cota[2];
    mapaResultado[sensores.posF][sensores.posC + 1] = sensores.superficie[3];
    mapaCotas[sensores.posF][sensores.posC + 1] = sensores.cota[3];
    mapaResultado[sensores.posF - 2][sensores.posC] = sensores.superficie[4];
    mapaCotas[sensores.posF - 2][sensores.posC] = sensores.cota[4];
    mapaResultado[sensores.posF - 2][sensores.posC + 1] = sensores.superficie[5];
    mapaCotas[sensores.posF - 2][sensores.posC + 1] = sensores.cota[5];
    mapaResultado[sensores.posF - 2][sensores.posC + 2] = sensores.superficie[6];
    mapaCotas[sensores.posF - 2][sensores.posC + 2] = sensores.cota[6];
    mapaResultado[sensores.posF - 1][sensores.posC + 2] = sensores.superficie[7];
    mapaCotas[sensores.posF - 1][sensores.posC + 2] = sensores.cota[7];
    mapaResultado[sensores.posF][sensores.posC + 2] = sensores.superficie[8];
    mapaCotas[sensores.posF][sensores.posC + 2] = sensores.cota[8];
    mapaResultado[sensores.posF - 3][sensores.posC] = sensores.superficie[9];
    mapaCotas[sensores.posF - 3][sensores.posC] = sensores.cota[9];
    mapaResultado[sensores.posF - 3][sensores.posC + 1] = sensores.superficie[10];
    mapaCotas[sensores.posF - 3][sensores.posC + 1] = sensores.cota[10];
    mapaResultado[sensores.posF - 3][sensores.posC + 2] = sensores.superficie[11];
    mapaCotas[sensores.posF - 3][sensores.posC + 2] = sensores.cota[11];
    mapaResultado[sensores.posF - 3][sensores.posC + 3] = sensores.superficie[12];
    mapaCotas[sensores.posF - 3][sensores.posC + 3] = sensores.cota[12];
    mapaResultado[sensores.posF - 2][sensores.posC + 3] = sensores.superficie[13];
    mapaCotas[sensores.posF - 2][sensores.posC + 3] = sensores.cota[13];
    mapaResultado[sensores.posF - 1][sensores.posC + 3] = sensores.superficie[14];
    mapaCotas[sensores.posF - 1][sensores.posC + 3] = sensores.cota[14];
    mapaResultado[sensores.posF][sensores.posC + 3] = sensores.superficie[15];
    mapaCotas[sensores.posF][sensores.posC + 3] = sensores.cota[15];
    break;
  case este:
    for (int j = 1; j < 4; j++)
      for (int i = -j; i <= j; i++)
      {
        mapaResultado[sensores.posF + i][sensores.posC + j] = sensores.superficie[pos];
        mapaCotas[sensores.posF + i][sensores.posC + j] = sensores.cota[pos++];
      }
    break;
  case sureste:
    mapaResultado[sensores.posF][sensores.posC + 1] = sensores.superficie[1];
    mapaCotas[sensores.posF][sensores.posC + 1] = sensores.cota[1];
    mapaResultado[sensores.posF + 1][sensores.posC + 1] = sensores.superficie[2];
    mapaCotas[sensores.posF + 1][sensores.posC + 1] = sensores.cota[2];
    mapaResultado[sensores.posF + 1][sensores.posC] = sensores.superficie[3];
    mapaCotas[sensores.posF + 1][sensores.posC] = sensores.cota[3];
    mapaResultado[sensores.posF][sensores.posC + 2] = sensores.superficie[4];
    mapaCotas[sensores.posF][sensores.posC + 2] = sensores.cota[4];
    mapaResultado[sensores.posF + 1][sensores.posC + 2] = sensores.superficie[5];
    mapaCotas[sensores.posF + 1][sensores.posC + 2] = sensores.cota[5];
    mapaResultado[sensores.posF + 2][sensores.posC + 2] = sensores.superficie[6];
    mapaCotas[sensores.posF + 2][sensores.posC + 2] = sensores.cota[6];
    mapaResultado[sensores.posF + 2][sensores.posC + 1] = sensores.superficie[7];
    mapaCotas[sensores.posF + 2][sensores.posC + 1] = sensores.cota[7];
    mapaResultado[sensores.posF + 2][sensores.posC] = sensores.superficie[8];
    mapaCotas[sensores.posF + 2][sensores.posC] = sensores.cota[8];
    mapaResultado[sensores.posF][sensores.posC + 3] = sensores.superficie[9];
    mapaCotas[sensores.posF][sensores.posC + 3] = sensores.cota[9];
    mapaResultado[sensores.posF + 1][sensores.posC + 3] = sensores.superficie[10];
    mapaCotas[sensores.posF + 1][sensores.posC + 3] = sensores.cota[10];
    mapaResultado[sensores.posF + 2][sensores.posC + 3] = sensores.superficie[11];
    mapaCotas[sensores.posF + 2][sensores.posC + 3] = sensores.cota[11];
    mapaResultado[sensores.posF + 3][sensores.posC + 3] = sensores.superficie[12];
    mapaCotas[sensores.posF + 3][sensores.posC + 3] = sensores.cota[12];
    mapaResultado[sensores.posF + 3][sensores.posC + 2] = sensores.superficie[13];
    mapaCotas[sensores.posF + 3][sensores.posC + 2] = sensores.cota[13];
    mapaResultado[sensores.posF + 3][sensores.posC + 1] = sensores.superficie[14];
    mapaCotas[sensores.posF + 3][sensores.posC + 1] = sensores.cota[14];
    mapaResultado[sensores.posF + 3][sensores.posC] = sensores.superficie[15];
    mapaCotas[sensores.posF + 3][sensores.posC] = sensores.cota[15];
    break;
  case sur:
    for (int j = 1; j < 4; j++)
      for (int i = -j; i <= j; i++)
      {
        mapaResultado[sensores.posF + j][sensores.posC - i] = sensores.superficie[pos];
        mapaCotas[sensores.posF + j][sensores.posC - i] = sensores.cota[pos++];
      }
    break;
  case suroeste:
    mapaResultado[sensores.posF + 1][sensores.posC] = sensores.superficie[1];
    mapaCotas[sensores.posF + 1][sensores.posC] = sensores.cota[1];
    mapaResultado[sensores.posF + 1][sensores.posC - 1] = sensores.superficie[2];
    mapaCotas[sensores.posF + 1][sensores.posC - 1] = sensores.cota[2];
    mapaResultado[sensores.posF][sensores.posC - 1] = sensores.superficie[3];
    mapaCotas[sensores.posF][sensores.posC - 1] = sensores.cota[3];
    mapaResultado[sensores.posF + 2][sensores.posC] = sensores.superficie[4];
    mapaCotas[sensores.posF + 2][sensores.posC] = sensores.cota[4];
    mapaResultado[sensores.posF + 2][sensores.posC - 1] = sensores.superficie[5];
    mapaCotas[sensores.posF + 2][sensores.posC - 1] = sensores.cota[5];
    mapaResultado[sensores.posF + 2][sensores.posC - 2] = sensores.superficie[6];
    mapaCotas[sensores.posF + 2][sensores.posC - 2] = sensores.cota[6];
    mapaResultado[sensores.posF + 1][sensores.posC - 2] = sensores.superficie[7];
    mapaCotas[sensores.posF + 1][sensores.posC - 2] = sensores.cota[7];
    mapaResultado[sensores.posF][sensores.posC - 2] = sensores.superficie[8];
    mapaCotas[sensores.posF][sensores.posC - 2] = sensores.cota[8];
    mapaResultado[sensores.posF + 3][sensores.posC] = sensores.superficie[9];
    mapaCotas[sensores.posF + 3][sensores.posC] = sensores.cota[9];
    mapaResultado[sensores.posF + 3][sensores.posC - 1] = sensores.superficie[10];
    mapaCotas[sensores.posF + 3][sensores.posC - 1] = sensores.cota[10];
    mapaResultado[sensores.posF + 3][sensores.posC - 2] = sensores.superficie[11];
    mapaCotas[sensores.posF + 3][sensores.posC - 2] = sensores.cota[11];
    mapaResultado[sensores.posF + 3][sensores.posC - 3] = sensores.superficie[12];
    mapaCotas[sensores.posF + 3][sensores.posC - 3] = sensores.cota[12];
    mapaResultado[sensores.posF + 2][sensores.posC - 3] = sensores.superficie[13];
    mapaCotas[sensores.posF + 2][sensores.posC - 3] = sensores.cota[13];
    mapaResultado[sensores.posF + 1][sensores.posC - 3] = sensores.superficie[14];
    mapaCotas[sensores.posF + 1][sensores.posC - 3] = sensores.cota[14];
    mapaResultado[sensores.posF][sensores.posC - 3] = sensores.superficie[15];
    mapaCotas[sensores.posF][sensores.posC - 3] = sensores.cota[15];
    break;
  case oeste:
    for (int j = 1; j < 4; j++)
      for (int i = -j; i <= j; i++)
      {
        mapaResultado[sensores.posF - i][sensores.posC - j] = sensores.superficie[pos];
        mapaCotas[sensores.posF - i][sensores.posC - j] = sensores.cota[pos++];
      }
    break;
  case noroeste:
    mapaResultado[sensores.posF][sensores.posC - 1] = sensores.superficie[1];
    mapaCotas[sensores.posF][sensores.posC - 1] = sensores.cota[1];
    mapaResultado[sensores.posF - 1][sensores.posC - 1] = sensores.superficie[2];
    mapaCotas[sensores.posF - 1][sensores.posC - 1] = sensores.cota[2];
    mapaResultado[sensores.posF - 1][sensores.posC] = sensores.superficie[3];
    mapaCotas[sensores.posF - 1][sensores.posC] = sensores.cota[3];
    mapaResultado[sensores.posF][sensores.posC - 2] = sensores.superficie[4];
    mapaCotas[sensores.posF][sensores.posC - 2] = sensores.cota[4];
    mapaResultado[sensores.posF - 1][sensores.posC - 2] = sensores.superficie[5];
    mapaCotas[sensores.posF - 1][sensores.posC - 2] = sensores.cota[5];
    mapaResultado[sensores.posF - 2][sensores.posC - 2] = sensores.superficie[6];
    mapaCotas[sensores.posF - 2][sensores.posC - 2] = sensores.cota[6];
    mapaResultado[sensores.posF - 2][sensores.posC - 1] = sensores.superficie[7];
    mapaCotas[sensores.posF - 2][sensores.posC - 1] = sensores.cota[7];
    mapaResultado[sensores.posF - 2][sensores.posC] = sensores.superficie[8];
    mapaCotas[sensores.posF - 2][sensores.posC] = sensores.cota[8];
    mapaResultado[sensores.posF][sensores.posC - 3] = sensores.superficie[9];
    mapaCotas[sensores.posF][sensores.posC - 3] = sensores.cota[9];
    mapaResultado[sensores.posF - 1][sensores.posC - 3] = sensores.superficie[10];
    mapaCotas[sensores.posF - 1][sensores.posC - 3] = sensores.cota[10];
    mapaResultado[sensores.posF - 2][sensores.posC - 3] = sensores.superficie[11];
    mapaCotas[sensores.posF - 2][sensores.posC - 3] = sensores.cota[11];
    mapaResultado[sensores.posF - 3][sensores.posC - 3] = sensores.superficie[12];
    mapaCotas[sensores.posF - 3][sensores.posC - 3] = sensores.cota[12];
    mapaResultado[sensores.posF - 3][sensores.posC - 2] = sensores.superficie[13];
    mapaCotas[sensores.posF - 3][sensores.posC - 2] = sensores.cota[13];
    mapaResultado[sensores.posF - 3][sensores.posC - 1] = sensores.superficie[14];
    mapaCotas[sensores.posF - 3][sensores.posC - 1] = sensores.cota[14];
    mapaResultado[sensores.posF - 3][sensores.posC] = sensores.superficie[15];
    mapaCotas[sensores.posF - 3][sensores.posC] = sensores.cota[15];
    break;
  }
}

/**
 * @brief Determina si una casilla es transitable para el ingeniero.
 * @param f Fila de la casilla.
 * @param c Columna de la casilla.
 * @param tieneZapatillas Indica si el agente posee las zapatillas.
 * @return true si la casilla es transitable (no es muro ni precipicio).
 */
bool ComportamientoIngeniero::EsCasillaTransitableLevel0(int f, int c, bool tieneZapatillas)
{
  if (f < 0 || f >= mapaResultado.size() || c < 0 || c >= mapaResultado[0].size())
    return false;
  return es_camino(mapaResultado[f][c]); // Solo 'C', 'D', 'U' son transitables en Nivel 0
}

/**
 * @brief Comprueba si la casilla de delante es accesible por diferencia de altura.
 * Para el ingeniero: desnivel máximo 1 sin zapatillas, 2 con zapatillas.
 * @param actual Estado actual del agente (fila, columna, orientacion, zap).
 * @return true si el desnivel con la casilla de delante es admisible.
 */
bool ComportamientoIngeniero::EsAccesiblePorAltura(const ubicacion &actual, bool zap)
{
  ubicacion del = Delante(actual);
  if (del.f < 0 || del.f >= mapaCotas.size() || del.c < 0 || del.c >= mapaCotas[0].size())
    return false;
  int desnivel = abs(mapaCotas[del.f][del.c] - mapaCotas[actual.f][actual.c]);
  if (zap && desnivel > 2)
    return false;
  if (!zap && desnivel > 1)
    return false;
  return true;
}

/**
 * @brief Devuelve la posición (fila, columna) de la casilla que hay delante del agente.
 * Calcula la casilla frontal según la orientación actual (8 direcciones).
 * @param actual Estado actual del agente (fila, columna, orientacion).
 * @return Estado con la fila y columna de la casilla de enfrente.
 */
ubicacion ComportamientoIngeniero::Delante(const ubicacion &actual) const
{
  ubicacion delante = actual;
  switch (actual.brujula)
  {
  case 0:
    delante.f--;
    break; // norte
  case 1:
    delante.f--;
    delante.c++;
    break; // noreste
  case 2:
    delante.c++;
    break; // este
  case 3:
    delante.f++;
    delante.c++;
    break; // sureste
  case 4:
    delante.f++;
    break; // sur
  case 5:
    delante.f++;
    delante.c--;
    break; // suroeste
  case 6:
    delante.c--;
    break; // oeste
  case 7:
    delante.f--;
    delante.c--;
    break; // noroeste
  }
  return delante;
}

/**
 * @brief Imprime por consola la secuencia de acciones de un plan.
 *
 * @param plan  Lista de acciones del plan.
 */
void ComportamientoIngeniero::PintaPlan(const list<Action> &plan)
{
  auto it = plan.begin();
  while (it != plan.end())
  {
    if (*it == WALK)
    {
      cout << "W ";
    }
    else if (*it == JUMP)
    {
      cout << "J ";
    }
    else if (*it == TURN_SR)
    {
      cout << "r ";
    }
    else if (*it == TURN_SL)
    {
      cout << "l ";
    }
    else if (*it == COME)
    {
      cout << "C ";
    }
    else if (*it == IDLE)
    {
      cout << "I ";
    }
    else
    {
      cout << "-_ ";
    }
    it++;
  }
  cout << "( longitud " << plan.size() << ")" << endl;
}

/**
 * @brief Imprime las coordenadas y operaciones de un plan de tubería.
 *
 * @param plan  Lista de pasos (fila, columna, operación),
 *              donde operacion = -1 (DIG), operación = 1 (RAISE).
 */
void ComportamientoIngeniero::PintaPlan(const list<Paso> &plan)
{
  auto it = plan.begin();
  while (it != plan.end())
  {
    cout << it->fil << ", " << it->col << " (" << it->op << ")\n";
    it++;
  }
  cout << "( longitud " << plan.size() << ")" << endl;
}

/**
 * @brief Convierte un plan de acciones en una lista de casillas para
 *        su visualización en el mapa 2D.
 *
 * @param st    Estado de partida.
 * @param plan  Lista de acciones del plan.
 */
void ComportamientoIngeniero::VisualizaPlan(const ubicacion &st,
                                            const list<Action> &plan)
{
  listaPlanCasillas.clear();
  ubicacion cst = st;

  listaPlanCasillas.push_back({cst.f, cst.c, WALK});
  auto it = plan.begin();
  while (it != plan.end())
  {

    switch (*it)
    {
    case JUMP:
      switch (cst.brujula)
      {
      case 0:
        cst.f--;
        break;
      case 1:
        cst.f--;
        cst.c++;
        break;
      case 2:
        cst.c++;
        break;
      case 3:
        cst.f++;
        cst.c++;
        break;
      case 4:
        cst.f++;
        break;
      case 5:
        cst.f++;
        cst.c--;
        break;
      case 6:
        cst.c--;
        break;
      case 7:
        cst.f--;
        cst.c--;
        break;
      }
      if (cst.f >= 0 && cst.f < mapaResultado.size() &&
          cst.c >= 0 && cst.c < mapaResultado[0].size())
        listaPlanCasillas.push_back({cst.f, cst.c, JUMP});
    case WALK:
      switch (cst.brujula)
      {
      case 0:
        cst.f--;
        break;
      case 1:
        cst.f--;
        cst.c++;
        break;
      case 2:
        cst.c++;
        break;
      case 3:
        cst.f++;
        cst.c++;
        break;
      case 4:
        cst.f++;
        break;
      case 5:
        cst.f++;
        cst.c--;
        break;
      case 6:
        cst.c--;
        break;
      case 7:
        cst.f--;
        cst.c--;
        break;
      }
      if (cst.f >= 0 && cst.f < mapaResultado.size() &&
          cst.c >= 0 && cst.c < mapaResultado[0].size())
        listaPlanCasillas.push_back({cst.f, cst.c, WALK});
      break;
    case TURN_SR:
      cst.brujula = (Orientacion) (( (int) cst.brujula + 1) % 8);
      break;
    case TURN_SL:
      cst.brujula = (Orientacion) (( (int) cst.brujula + 7) % 8);
      break;
    }
    it++;
  }
}

/**
 * @brief Convierte un plan de tubería en la lista de casillas usada
 *        por el sistema de visualización.
 *
 * @param st    Estado de partida (no utilizado directamente).
 * @param plan  Lista de pasos del plan de tubería.
 */
void ComportamientoIngeniero::VisualizaRedTuberias(const list<Paso> &plan)
{
  listaCanalizacionTuberias.clear();
  auto it = plan.begin();
  while (it != plan.end())
  {
    listaCanalizacionTuberias.push_back({it->fil, it->col, it->op});
    it++;
  }
}
